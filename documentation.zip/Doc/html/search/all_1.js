var searchData=
[
  ['actor_5fsearch_0',['actor_search',['../namespace_api.html#aa0e59bb5c63ce6c99860e448476a4f58',1,'Api']]],
  ['anime_1',['Anime',['../classdorama__and__anime_1_1_anime.html',1,'dorama_and_anime']]],
  ['api_2',['API',['../namespace_api.html#ac1c65b327a0c4d9a3a9a3ea6572e970f',1,'Api']]],
  ['api_3',['Api',['../namespace_api.html',1,'']]],
  ['api_2epy_4',['Api.py',['../_api_8py.html',1,'']]],
  ['author_20s_5',['Author(s)',['../namespacedocstring.html#author_doxygen_example',1,'']]]
];
