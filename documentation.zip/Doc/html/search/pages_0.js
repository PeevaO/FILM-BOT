var searchData=
[
  ['readme_0',['README',['../md__c_1_2_users_2_rosto4ek_2_pycharm_projects_2_telegram__bot_2_r_e_a_d_m_e.html',1,'']]]
];
