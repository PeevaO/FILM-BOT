var searchData=
[
  ['s_0',['Author(s)',['../namespacedocstring.html#author_doxygen_example',1,'']]]
];
