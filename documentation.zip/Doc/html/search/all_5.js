var searchData=
[
  ['generalmessages_0',['GeneralMessages',['../namespace_general_messages.html',1,'']]],
  ['generalmessages_2epy_1',['GeneralMessages.py',['../_general_messages_8py.html',1,'']]],
  ['genre_5fsearch_2',['genre_search',['../namespace_api.html#addef021dd74d14073dd15ddb51738ebe',1,'Api']]]
];
