var searchData=
[
  ['anime_0',['Anime',['../classdorama__and__anime_1_1_anime.html',1,'dorama_and_anime']]]
];
