var searchData=
[
  ['docstring_0',['docstring',['../namespacedocstring.html',1,'']]],
  ['dorama_5fand_5fanime_1',['dorama_and_anime',['../namespacedorama__and__anime.html',1,'']]],
  ['doranimebot_2',['DoranimeBot',['../namespace_doranime_bot.html',1,'']]]
];
