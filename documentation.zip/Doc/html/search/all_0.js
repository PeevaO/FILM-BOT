var searchData=
[
  ['_5f_5finit_5f_5f_0',['__init__',['../classdorama__and__anime_1_1_dorama.html#a9d4a2203358e2f910f249063edf4ff0f',1,'dorama_and_anime.Dorama.__init__()'],['../classdorama__and__anime_1_1_anime.html#a67d4bd734079ac050dc7f53637f9d35f',1,'dorama_and_anime.Anime.__init__()']]],
  ['_5f_5fstr_5f_5f_1',['__str__',['../classdorama__and__anime_1_1_dorama.html#a8d70c0183839b33d2997e082af15d549',1,'dorama_and_anime.Dorama.__str__()'],['../classdorama__and__anime_1_1_anime.html#a2001806e2f05e4b19c83de8050c001b0',1,'dorama_and_anime.Anime.__str__()']]]
];
