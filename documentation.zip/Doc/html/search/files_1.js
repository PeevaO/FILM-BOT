var searchData=
[
  ['dorama_5fand_5fanime_2epy_0',['dorama_and_anime.py',['../dorama__and__anime_8py.html',1,'']]],
  ['doranimebot_2epy_1',['DoranimeBot.py',['../_doranime_bot_8py.html',1,'']]]
];
