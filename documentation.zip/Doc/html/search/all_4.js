var searchData=
[
  ['docstring_0',['docstring',['../namespacedocstring.html',1,'']]],
  ['dorama_1',['Dorama',['../classdorama__and__anime_1_1_dorama.html',1,'dorama_and_anime']]],
  ['dorama_5fand_5fanime_2',['dorama_and_anime',['../namespacedorama__and__anime.html',1,'']]],
  ['dorama_5fand_5fanime_2epy_3',['dorama_and_anime.py',['../dorama__and__anime_8py.html',1,'']]],
  ['doranimebot_4',['DoranimeBot',['../namespace_doranime_bot.html',1,'']]],
  ['doranimebot_2epy_5',['DoranimeBot.py',['../_doranime_bot_8py.html',1,'']]]
];
