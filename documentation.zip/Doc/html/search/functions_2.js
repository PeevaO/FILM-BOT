var searchData=
[
  ['genre_5fsearch_0',['genre_search',['../namespace_api.html#addef021dd74d14073dd15ddb51738ebe',1,'Api']]]
];
