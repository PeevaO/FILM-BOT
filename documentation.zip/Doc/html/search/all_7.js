var searchData=
[
  ['name_0',['name',['../classdorama__and__anime_1_1_dorama.html#a61b811559a324027f943d3fd70f9e994',1,'dorama_and_anime.Dorama.name'],['../classdorama__and__anime_1_1_anime.html#a1e4299b8635eda39fea2b774e64f0dee',1,'dorama_and_anime.Anime.name']]]
];
